export default function OldBook() {
    return (
        <div>
            <h1>OldBook</h1>
        </div>
    );
}