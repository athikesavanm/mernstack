// Child2 component
import Child3 from './child3';

function Child2({ names }) {
    return (
        <Child3 names={names} />
    );
    }

    export default Child2;
