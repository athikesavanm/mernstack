export default function NewBook() {
    return (
        <div>
            <h1>NewBook</h1>
        </div>
    );
}