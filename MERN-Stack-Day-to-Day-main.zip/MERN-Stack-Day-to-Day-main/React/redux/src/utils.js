
export function Home() {
    return <h1>Home</h1>;
}
export function About() {
    return <h1>About</h1>;
}
export function New() {
    return <h1>New</h1>;
}
export function Old() {
    return <h1>Old</h1>;
}


